# Quarter RPG V0.1

Free Phaser 3 mobile-browser prototype. Original procedural placeholder art.

## Features
- Quarter-view 2D movement (8 directions) with touch joystick or WASD/arrows
- Auto attack, critical damage, damage numbers and impact effects
- Monster chasing, respawn, loot scatter and pickup magnet
- Gold, XP, levels, HP, depth sorting, camera follow

## Publish using GitHub Pages (mobile)
1. Upload `index.html`, `.nojekyll`, and the `src` folder to the root of `seeker6131/quarter-rpg` (keep folder paths).
2. Commit the changes.
3. Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. Visit `https://seeker6131.github.io/quarter-rpg/` after deployment.

Internet is required to load Phaser from jsDelivr. No API keys, paid services, server or build tools required.

## Notes
V0.1 is a prototype with procedural art, not yet a full 3/4-direction character sprite system. Persistence, audio, equipment and map collisions are planned for later releases. No claims of live Android testing.
